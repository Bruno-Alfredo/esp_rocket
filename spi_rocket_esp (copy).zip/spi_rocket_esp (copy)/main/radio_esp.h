#ifndef RADIO_ESP_H
#define RADIO_ESP_H

//#include <mqueue.h>


struct radio_struct {
   // mqd_t _mq_down;
   // mqd_t _mq_up;
};

#endif /* RADIO_ESP_H */
