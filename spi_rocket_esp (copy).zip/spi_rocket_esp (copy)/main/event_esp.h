#ifndef EVENT_ESP_H
#define EVENT_ESP_H

#include "sm_rocket.h"

struct event_manager_struct {
    event_t _event;
    SemaphoreHandle_t _sync;
};

#endif /* EVENT_ESP_H */
