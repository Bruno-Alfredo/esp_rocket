#ifndef MESSAGE_MANAGER_ESP_H
#define MESSAGE_MANAGER_ESP_H

struct message_manager_struct {
};

#endif /* MESSAGE_MANAGER_ESP_H */
