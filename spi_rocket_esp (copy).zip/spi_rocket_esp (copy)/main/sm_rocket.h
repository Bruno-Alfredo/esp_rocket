#ifndef SM_ROCKET_H
#define SM_ROCKET_H

#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "sdkconfig.h"
#include "freertos/semphr.h"
#include "esp_timer.h"
#include "driver/spi_master.h"
#include "esp32/rom/ets_sys.h"
#include "driver/gpio.h"
#include "esp_system.h"

#include "Si446x.h"

#include "message_manager.h"
#include "radio.h"
#include "timer_manager.h"
#include "event.h"

typedef enum {
    ST_INIT = 0, ST_WAIT_ACK, ST_SENDING_DATA, ST_RECEIVING_DATA
} estados;

typedef enum {
    EV_ACK = EV_USER, EV_SOT, EV_TOUT_SOT, EV_TOUT_SESSION_TX, EV_TOUT_NO_RX, 
    EV_TOUT_SESSION_RX, EV_EOT, EV_DADOS, EV_DATA_SENT, EV_MAX
} eventos;

#define SOT_TIMER_ID 0
#define DOWNLINK_TIMER_ID 0
#define UPLINK_TIMER_ID 0
#define UPLINK_RX_TIMER_ID 1

#define CHANNEL 0
#define MAX_PACKET_SIZE 64

#define NORMALPRIO     5

#define GPIO_MOSI 15
#define GPIO_MISO 2
#define GPIO_SCLK 14
#define GPIO_CS 12
#define GPIO_SDN 16

extern spi_device_handle_t handle;

extern estados g_state;
extern timer_manager_t g_timer_mgr;
extern message_manager_t g_msg_mgr;
extern radio_t g_radio;
extern event_manager_t g_event_mgr;
// virtual_timer_t vt_obj1;
// virtual_timer_t vt_obj2;
// virtual_timer_t vt_obj3;

void send_sot();
void send_eot();
void send_first_data();
void send_data();
void processa_dados();
void tout_rx_sessao();

static void cb1(void* arg);
static void cb2(void* arg);
static void cb3(void* arg);
esp_timer_handle_t cb1_timer;
esp_timer_handle_t cb2_timer;
esp_timer_handle_t cb3_timer;

void init_sm();
void processa_evento(event_t input);

#endif /* SM_ROCKET_H */
