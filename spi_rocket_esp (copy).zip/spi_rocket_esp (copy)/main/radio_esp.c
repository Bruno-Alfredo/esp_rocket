
#include <stdio.h>
#include <string.h>

#include "sm_rocket.h"
#include "radio.h"
#include "event.h"


#define BUFFER_SIZE 3


char g_buffer[BUFFER_SIZE];
uint8_t g_buffer1[0];

spi_device_handle_t handle;

const char MQ_NAME_DOWN[] = "/rocket_down_mq2";
const char MQ_NAME_UP[] = "/rocket_up_mq2";


void Thread1( void * parameter)
{
        while (1) {
         Si446x_RX(CHANNEL);             //TODO  é necessário?
         vTaskDelay(300 / portTICK_PERIOD_MS);

        #if !SI446X_FIXED_LENGTH
           uint8_t len;
           Si446x_read(&len, 1);
        #else
           uint8_t len = SI446X_FIXED_LENGTH;
        #endif
         if (len != 0){
            //   chprintf((BaseSequentialStream *)&SD1, "\nRssi=%d", Si446x_getRSSI());
           printf("\ntamanho=%d\n", len);
           if (len > MAX_PACKET_SIZE)
               len = MAX_PACKET_SIZE;
           Si446x_read((uint8_t*)g_buffer1, len);                                    
          // sdRead(&SD1, g_buffer1, 1);     // buffer[0] =='E' 'A'   buffer[3] =0;
           printf("\nrecebeu %c%c%c", g_buffer1[0], g_buffer1[1], g_buffer1[2]);
           if(g_buffer1[0] == 'A') {
              printf("ack!\n");
              event_post(&g_event_mgr, EV_ACK);
          }else if(g_buffer1[0] == 'E') {
              event_post(&g_event_mgr, EV_EOT);
          }else {
              event_post(&g_event_mgr, EV_DADOS);
          }
         }
           vTaskDelay(10 / portTICK_PERIOD_MS);
        }
        
}

// TIME_S2i mS2I uS2I I2S
int radio_init(radio_t* radio) {
    int rc = 0;
   
    spi_bus_config_t buscfg={
        .mosi_io_num=GPIO_MOSI,
        .miso_io_num=GPIO_MISO,
        .sclk_io_num=GPIO_SCLK,
        .quadwp_io_num=-1,
        .quadhd_io_num=-1
    };

    spi_device_interface_config_t devcfg={
        .command_bits=0,
        .address_bits=0,
        .dummy_bits=0,
        .clock_speed_hz=1000000,
        .duty_cycle_pos=128,        //50% duty cycle
        .mode=0,
        .spics_io_num=-1,
        .cs_ena_posttrans=3, 
        .queue_size=3
    };
    
     spi_bus_initialize(HSPI_HOST, &buscfg, 1);
     spi_bus_add_device(HSPI_HOST, &devcfg, &handle);

     gpio_pad_select_gpio(GPIO_CS);
     gpio_set_direction(GPIO_CS, GPIO_MODE_OUTPUT);
     gpio_set_level(GPIO_CS, 1);

     gpio_pad_select_gpio(GPIO_SDN);
     gpio_set_direction(GPIO_SDN, GPIO_MODE_OUTPUT);

     Si446x_init();
     printf("Si4463 iniciado\n");

     xTaskCreate(Thread1, "Thread1", 4096, NULL, NORMALPRIO-1, NULL);
     
    return rc;
}

int radio_deinit(radio_t* radio) {
    int rc = 0;

    return rc;
}

int radio_send(radio_t* mgr, const uint8_t buffer[], int nbr_bytes) {
    int rc = 0;
   // sdWrite(&SD1, (const uint8_t*) buffer, nbr_bytes);
    for(uint8_t i=0;i<nbr_bytes;i++)
    {
       printf("%c", buffer[i]);
    }
    printf(" \n");
    Si446x_TX((uint8_t*)buffer, nbr_bytes, CHANNEL, SI446X_STATE_RX);
    return rc;
}

int radio_receive(radio_t* mgr, const uint8_t buffer[], int nbr_bytes) {
    int rc = 0;

    return rc;
}

void radio_make_silent(radio_t* mgr) {
}
