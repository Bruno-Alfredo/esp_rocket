
#include "sm_rocket.h"
#include "event.h"

#define SOT_TIMEOUT 3
#define DOWNLINK_DURATION 6
#define UPLINK_DURATION 4
#define NO_RESPONSE_TIMEOUT 3




/*
void cb1(void *arg)
{
     event_post(&g_event_mgr, EV_TOUT_SOT);

}

void cb2(void *arg)
{
     event_post(&g_event_mgr, EV_TOUT_SESSION_RX);


}
void cb3(void *arg)
{
     event_post(&g_event_mgr, EV_TOUT_NO_RX);
     palTogglePad(LED_PORT, LED_PAD);

}   */

void send_sot() {
    const uint8_t sot[] = "SOT";                             //1seg=1000000
    if (radio_send(&g_radio, sot, sizeof(sot))) {}
     /*   perror("On sending SOT in send_sot()");*/
     // chVTSet(&vt_obj1, TIME_MS2I(1000), cb1, (void *)&vt_obj1);        //TIMEOUT SOT, 1 seg gera cb1     
      esp_timer_start_once(cb1_timer, 1000000);
  /*  if (timer_set(&g_timer_mgr, SOT_TIMER_ID, SOT_TIMEOUT, EV_TOUT_SOT))
        perror("On setting timer SOT_TIMER_ID in send_sot()");*/
}

void send_first_data() {
    int actual_nbr_bytes;
    uint8_t buffer[3];
    int nbr_bytes = sizeof(buffer);

   // printf("Enviando o primeiro dado da sessão. Continua no estado 'ENVIANDO DADOS'\n");
    if ((actual_nbr_bytes = message_retrieve(&g_msg_mgr, buffer, nbr_bytes)) == 0) {
      //  printf("In send_first_data(), there was no message to be retrieved from the queue.\n");
        return;
    }
    nbr_bytes = actual_nbr_bytes;
   /* if ((actual_nbr_bytes = radio_send(&g_radio, buffer, nbr_bytes)) != nbr_bytes) {
        printf("In send_first_data(), radio didn't send all bytes.\n");
    }
    if (timer_set(&g_timer_mgr, DOWNLINK_TIMER_ID, DOWNLINK_DURATION, EV_TOUT_SESSION_TX))
        printf("Error on setting timer DOWNLINK_TIMER_ID in send_first_data().\n"); */
}

void send_eot() {
    const uint8_t eot[] = "EOT";
    if (radio_send(&g_radio, eot, sizeof(eot))) {}
    /*    printf("Error on sending EOT in send_eot().\n");*/
    
  //  chVTSet(&vt_obj2, TIME_MS2I(1500), cb2, (void *)&vt_obj2);  //set uplink_timer
      esp_timer_start_once(cb2_timer, 1500000);
   /* if (timer_set(&g_timer_mgr, UPLINK_TIMER_ID, UPLINK_DURATION, EV_TOUT_SESSION_RX))
        printf("Error on setting timer UPLINK_TIMER_ID in send_eot().\n");  */

/*    if (timer_set(&g_timer_mgr, UPLINK_RX_TIMER_ID, NO_RESPONSE_TIMEOUT, EV_TOUT_NO_RX))
        printf("Error on setting timer UPLINK_RX_TIMER_ID in send_eot().\n");*/
   // chVTSet(&vt_obj3, TIME_MS2I(1000), cb3, (void *)&vt_obj3);  //set uplink_RX_timer  nunca será gerado??? pois cb2 sempre occore primeiro?
      esp_timer_start_once(cb3_timer, 1000000);
}

void send_data() {
    int actual_nbr_bytes;
    uint8_t buffer[3];
    int nbr_bytes = sizeof(buffer);

  /*  printf("Enviando dados. Continua no estado 'ENVIANDO DADOS'\n");
    if ((actual_nbr_bytes = message_retrieve(&g_msg_mgr, buffer, nbr_bytes)) == 0) {
        printf("In send_first_data(), there was no message to be retrieved from the queue\n");
        return;
    }
    nbr_bytes = actual_nbr_bytes;
    if ((actual_nbr_bytes = radio_send(&g_radio, buffer, nbr_bytes)) != nbr_bytes) {
        printf("In send_first_data(), radio didn't send all bytes\n");
    }*/
}

void processa_dados() {
  //  printf("Continua no estado 'RECEBENDO DADOS'\n");
}

void tout_rx_sessao() {
  //  printf("In tout_rx_sessao(), session is longer than expected.\n");
  //  printf("Continua no estado 'RECEBENDO DADOS'\n");
}
