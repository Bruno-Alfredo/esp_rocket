
#include "sm_rocket.h"
#include "event.h"


timer_manager_t g_timer_mgr;
message_manager_t g_msg_mgr;
radio_t g_radio;
event_manager_t g_event_mgr;

static void cb1(void* arg)
{
   event_post(&g_event_mgr, EV_TOUT_SOT);
}
static void cb2(void* arg)
{
   event_post(&g_event_mgr, EV_TOUT_SESSION_RX);
}
static void cb3(void* arg)
{
   event_post(&g_event_mgr, EV_TOUT_NO_RX);
}
/*
void SI446X_CB_CMDTIMEOU()
{
   printf("oi\n");
}  */

/*
void my_timer_cb(uint8_t event) {
   // event_post(&g_event_mgr, event);
}  */

void setup_all()
{
  /*  if (timer_init_manager(&g_timer_mgr, 2, my_timer_cb)) {
      //  printf("Error creating timers.  Aborting program!\n");
      //  exit(-1);
    }  */
     const esp_timer_create_args_t cb1_args = {
            .callback = &cb1,
            .name = "sot_timeout"
    };
    esp_timer_create(&cb1_args, &cb1_timer);

    const esp_timer_create_args_t cb2_args = {
            .callback = &cb2,
            .name = "uplink_timer"
    };
    esp_timer_create(&cb2_args, &cb2_timer);   

    const esp_timer_create_args_t cb3_args = {
            .callback = &cb3,
            .name = "uplink_rx"
    };
    esp_timer_create(&cb3_args, &cb3_timer);   


    if (event_init_manager(&g_event_mgr)) {
      //  printf("Error creating event manager.  Aborting program!\n");
       // exit(-1);
    }
    if (radio_init(&g_radio)) {
     //   printf("Error creating radio.  Aborting program!\n");
     //   exit(-1);
    }
  /*  if (message_init_manager(&g_msg_mgr)) {
        printf("Error creating message manager.  Aborting program!\n");
        exit(-1);
    }  */
}

void stop_all()
{
 /*   event_deinit_manager(&g_event_mgr);
    if (timer_deinit_manager(&g_timer_mgr))
        printf("Error destroying timers.\n");  */
}

/*
void Thread2( void * parameter)
{
        while (1) {

            vTaskDelay(200 / portTICK_PERIOD_MS);
            event_post(&g_event_mgr, EV_ACK);
            vTaskDelay(300 / portTICK_PERIOD_MS);
            
            event_post(&g_event_mgr, EV_EOT);
            vTaskDelay(300 / portTICK_PERIOD_MS);
            
            event_post(&g_event_mgr, EV_EOT);
            vTaskDelay(300 / portTICK_PERIOD_MS);
            
            event_post(&g_event_mgr, EV_DADOS);    
            vTaskDelay(1500 / portTICK_PERIOD_MS);
        }
}    */
  
void Thread3( void * parameter)
{
    while(1) {
      event_t ev = event_wait(&g_event_mgr);
      //   printf("Evento recebido = %u\n", ev);
      if (ev != EV_INVALID)
         processa_evento(ev);
    }
}  

void app_main(void)
{
   
    setup_all();
   // chVTObjectInit(&vt_obj1);
   // chVTObjectInit(&vt_obj2);
   // chVTObjectInit(&vt_obj3);
    init_sm();
  //  chThdCreateStatic(waThread2, sizeof(waThread2), NORMALPRIO, Thread2, NULL);   //thread criada para enviar eventos e testar serial
 //   xTaskCreate(Thread2, "Thread2", 4096, NULL, NORMALPRIO, NULL); 
    xTaskCreate(Thread3, "Thread3", 8192, NULL, NORMALPRIO, NULL);

    while (1) {

      vTaskDelay(5000 / portTICK_PERIOD_MS);
    }

    stop_all();

    return 0;
}
