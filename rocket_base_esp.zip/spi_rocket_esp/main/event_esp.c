
#include <stdio.h>
#include "event.h"

int event_init_manager(event_manager_t* mgr) {
    int rc = 0;
    mgr->_sync = xSemaphoreCreateBinary();      //TODO ou &mgr->_sync = xSemaphoreCreateBinary();?
   /* if(rc = sem_init(&mgr->_sync, 0, 0)) {
        perror("On creating event semaphore:");
    }  */

    return rc;
}

int event_deinit_manager(event_manager_t* mgr) {
 /*   if(sem_destroy(&mgr->_sync))  {
        perror("On destroying the semaphore");
        return -1;
    } */
    return 0;
}


void event_post(event_manager_t* mgr, event_t ev) {
    mgr->_event = ev;
    xSemaphoreGive(mgr->_sync);
}

event_t event_wait(event_manager_t* mgr) {
    xSemaphoreTake(mgr->_sync, portMAX_DELAY);
    return mgr->_event;
}
