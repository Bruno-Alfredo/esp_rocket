#include <stdio.h>

#include "sm_base.h"


const char* EV_NAMES[] = {"EV_ACK", "EV_SOT", "EV_TOUT_SOT"," EV_TOUT", "EV_EOT", "EV_DATA_RECEIVED",
 "EV_SEND_DATA_BASE", "EV_TOUT_SESSAO", "EV_MAX", "desconhecido"
};

const char* ST_NAMES[] = {"ST_INIT", "ST_WAIT_SOT", "ST_WAIT_DATA", "ST_SEND_DATA", "desconhecido"
};

estados g_state;

void processa_evento(eventos input)
{
    switch (g_state) {
    case ST_WAIT_SOT:
        switch (input) {
        case EV_SOT:
            printf("Recebido SoT, enviando ACK, indo para ST_WAIT_DATA.\n");
            processa_sot();
            g_state = ST_WAIT_DATA;
            break;                                     //TODO case EV_EOT: SI446x_RX();?
        default:
          //  printf("Em WaitSOT recebeu e ignorou (%s)\n", EV_NAMES[input < EV_MAX ? input : EV_MAX]);
            break;
        }
        break;

    case ST_WAIT_DATA:
        switch (input) {
        case EV_SOT:
            printf("Recebido um SoT não-esperado, indo para ST_WAIT_SOT\n");
            unexpected_sot();
            g_state = ST_WAIT_SOT;
        case EV_TOUT_NO_RX:
            /* TODO: por segurança e informação, se não recebermos nada em um determinado período de tempo, voltamos para o estado de espera por link. */
            g_state = ST_WAIT_SOT;
            break;
        case EV_TOUT_SESSAO:
            tout_sessao();
            break;
        case EV_DATA_RECEIVED:
            processa_dados();
            break;
        case EV_EOT:
        //    printf("Recebido EOT, indo para ST_SEND_DATA\n");
            processa_send_data_base_begin();
            //g_state = ST_SEND_DATA;
            break;
        default:
        //    printf("Em ST_WAIT_DATA recebeu (%s)\n", EV_NAMES[input < EV_MAX ? input : EV_MAX]);
            break;
        }
        break;

    case ST_SEND_DATA:
        switch (input) {
        case EV_SEND_DATA_BASE:
            processa_send_data_base();
            break;
        case EV_TOUT:
      //      printf("Timeout ocorrido, indo para ST_WAIT_DATA\n");
            processa_tout();
            g_state = ST_WAIT_DATA;
            break;
        case EV_EOT:
      //      printf("Enviando EOT, indo para ST_WAIT_DATA\n");
            processa_eot_base();
            g_state = ST_WAIT_DATA;
            break;
        default:
     //       printf("Em ST_SEND_DATA recebeu (%s)\n", EV_NAMES[input < EV_MAX ? input : EV_MAX]);
            break;
        }
        break;
        
    default:
        break;
    }
}
