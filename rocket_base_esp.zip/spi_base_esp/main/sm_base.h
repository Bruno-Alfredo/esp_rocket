#ifndef SM_BASE_H
#define SM_BASE_H

#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>
#include <stdint.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "sdkconfig.h"
#include "freertos/semphr.h"
#include "esp_timer.h"
#include "driver/spi_master.h"
#include "esp32/rom/ets_sys.h"
#include "driver/gpio.h"
#include "esp_system.h"

#include "Si446x.h"


typedef enum {
    ST_INIT = 0, ST_WAIT_SOT, ST_WAIT_DATA, ST_SEND_DATA
} estados;

typedef enum {
 EV_ACK = 0, EV_SOT, EV_TOUT_SOT, EV_TOUT, EV_EOT, EV_EOT_BASE, EV_DATA_RECEIVED,
    EV_SEND_DATA_ROCKET,EV_SEND_DATA_BASE, EV_TOUT_NO_RX, EV_NO_DATA, EV_TOUT_SESSAO,
    EV_INVALID, EV_MAX
} eventos;

#define CHANNEL 0
#define MAX_PACKET_SIZE 64

#define NORMALPRIO     5

#define GPIO_MOSI 15
#define GPIO_MISO 2
#define GPIO_SCLK 14
#define GPIO_CS  12
#define GPIO_SDN 16
#define GPIO_IRQ 0

extern spi_device_handle_t handle;

extern estados g_state;

void init_sm();
int processa_sot();
void processa_tout_sot();
void processa_tout();
void processa_eot_base();
void processa_eot_rocket();
void processa_send_data();
void processa_no_data();
void processa_send_data_base();
void processa_send_data_base_begin();
void processa_dados();
void tout_sessao();
void unexpected_sot();

void processa_evento(eventos input);

#endif /* SM_BASE_H */
