
#include "sm_base.h"

eventos g_input = EV_INVALID;


//uint8_t g_buffer[1];

uint8_t g_buffer[MAX_PACKET_SIZE];

//semaphore_t g_sem;
SemaphoreHandle_t g_sem;
SemaphoreHandle_t g_mtx;
spi_device_handle_t handle;
//MUTEX_DECL(mtx);

const char MQ_NAME_UP[] = "/rocket_down_mq2";
const char MQ_NAME_DOWN[] = "/rocket_up_mq2";



void Thread1( void * parameter)
{
        while (1) { 
      
         xSemaphoreTake(g_mtx, portMAX_DELAY);   
         vTaskDelay(10 / portTICK_PERIOD_MS);
         if (gpio_get_level(GPIO_IRQ) == 0){
         //   printf("\ninterrupt ");
            Si446x_SERVICE();
         }
         xSemaphoreGive(g_mtx);   
   
        }  
}


void SI446X_CB_RXCOMPLETE(uint8_t len, int16_t rssi)
{
   if (len > MAX_PACKET_SIZE)
      len = MAX_PACKET_SIZE;
   Si446x_read((uint8_t*)g_buffer, len);

  // printf("\ntamanho=%d ",len);
   
   if(g_buffer[0] == 'S') {
             printf("Receiving a SOT\n");
             g_input = EV_SOT;
             xSemaphoreGive(g_sem);    
    } else if(g_buffer[0] == 'E') {
             printf("Receiving an EOT\n");
             g_input = EV_EOT;
             xSemaphoreGive(g_sem);    
    } else { 
             xSemaphoreGive(g_sem);
             printf("%d\n",g_buffer[0]);
             Si446x_RX(CHANNEL);                  //TODO é correto chamar aqui? teria que ser depois do mtxunlock?
    }
      printf("RSSI=%d\n", rssi);
}

void SI446X_CB_RXINVALID(int16_t rssi)
{
   printf("\nbad packet");
   Si446x_RX(CHANNEL);
   
}

void SI446X_CB_SENT()
{
  //  chprintf((BaseSequentialStream *)&SD1, "\nenviou ");
}

void send_ack()
{
    const char ack[] = "ACK";

    Si446x_TX((uint8_t*)ack, strlen(ack), CHANNEL, SI446X_STATE_RX);
   // sdWrite(&SD1, (const uint8_t*) ack, strlen(ack));
}

void send_eot()
{
    const char eot[] = "EOT";
   // sdWrite(&SD1, (const uint8_t*) eot, strlen(eot));
    Si446x_TX((uint8_t*)eot, strlen(eot), CHANNEL, SI446X_STATE_RX);
  
}

/*void timer_cb(union sigval value)
{
}*/

void setup_timers()
{
   
}


/*void mq_cb(union sigval value)
{
}*/


void setup_msgqueue()
{
    
  
}

void setup_all()
{
    g_sem = xSemaphoreCreateBinary(); 
    g_mtx = xSemaphoreCreateMutex();

    spi_bus_config_t buscfg={
        .mosi_io_num=GPIO_MOSI,
        .miso_io_num=GPIO_MISO,
        .sclk_io_num=GPIO_SCLK,
        .quadwp_io_num=-1,
        .quadhd_io_num=-1
    };
    spi_device_interface_config_t devcfg={
        .command_bits=0,
        .address_bits=0,
        .dummy_bits=0,
        .clock_speed_hz=1000000,
        .duty_cycle_pos=128,        //50% duty cycle
        .mode=0,
        .spics_io_num=-1,
        .cs_ena_posttrans=3, 
        .queue_size=7
    };
    spi_bus_initialize(HSPI_HOST, &buscfg, 1);
    spi_bus_add_device(HSPI_HOST, &devcfg, &handle);

    gpio_pad_select_gpio(GPIO_CS);
    gpio_set_direction(GPIO_CS, GPIO_MODE_OUTPUT);
    gpio_set_level(GPIO_CS, 1);

    gpio_pad_select_gpio(GPIO_SDN);
    gpio_set_direction(GPIO_SDN, GPIO_MODE_OUTPUT);
    gpio_pad_select_gpio(GPIO_IRQ);
    gpio_set_direction(GPIO_IRQ, GPIO_MODE_INPUT);


    setup_msgqueue();
    setup_timers();
}

void stop_timers()
{
}

void stop_msgqueue()
{
   
}

void stop_all()
{
    stop_msgqueue();
    stop_timers();
}

void start_timer_session()
{
}

// inicio codigo novo
void init_sm()
{
  //  printf (" 'esperando por SOT' \n ");
    g_state = ST_WAIT_SOT;
}

void tout_sessao()
{
  //  printf (" 'estouro no tempo de sessão' \n");
}

void unexpected_sot() {
     Si446x_RX(CHANNEL);
}

/*void cancela_timer(timer_t timer)                
{
   
}*/

int rnd;
int processa_sot()
{
   // cancela_timer(g_timer1);

    send_ack();
    return 0;
}

void processa_dados()
{
  //  printf(" 'continua a receber dados' \n");
}
void processa_send_data_base_begin() 
{
    printf("dados recebidos, transicao para o enviar dados\n");
    /* Mandando um EOT por enquanto só para testar o foguete */
    const char msg[] = "EOT";
   // sdWrite(&SD1, (const uint8_t*) msg, strlen(msg));
    Si446x_TX((uint8_t*)msg, strlen(msg), CHANNEL, SI446X_STATE_RX);
}

void processa_send_data_base()
{
   // printf(" 'continua a enviar dados da base' \n");
}
void processa_send_data()
{
  //  printf(" 'continua a enviar dados da base' \n");
    const char msg[] = "DATA";
    //sdWrite(&SD1, (const uint8_t*) msg, strlen(msg));
    //spiSelect(&SPID1);
    //spiSend(&SPID1, strlen(msg), (const uint8_t*) msg);
    //spiUnselect(&SPID1);
 
}
void processa_tout()
{
   // printf(" estouro no tempo, transicao para 'esperando dados' \n ");
}
void processa_eot_base()
{
  //  printf(" transicao para o estado 'esperando dados' \n");
}


void Thread2( void * parameter)
{
        while (1) {
         xSemaphoreTake(g_sem, portMAX_DELAY);
         xSemaphoreTake(g_mtx, portMAX_DELAY);   
         processa_evento(g_input);
         g_input = EV_INVALID;
         xSemaphoreGive(g_mtx);   
          
        }
}


void app_main(void)
{

    setup_all();

    init_sm();
    Si446x_init();
    printf("Si4463 iniciado\n");
  //  Si446x_setTxPower(SI446X_MAX_TX_POWER);
    Si446x_RX(CHANNEL);
   
    xTaskCreate(Thread1, "Thread1", 8192, NULL, NORMALPRIO-1, NULL);
    xTaskCreate(Thread2, "Thread2", 8192, NULL, NORMALPRIO, NULL);
    
    while (1) { 
     /*  g_input = EV_SOT;
            chSemSignal(&g_sem);
            chThdSleepMilliseconds(2000);
            
            g_input = EV_EOT;
            chSemSignal(&g_sem);   */
            vTaskDelay(5000 / portTICK_PERIOD_MS);
    }

    stop_all();
   // spiStop(&SPID1);
    return 0;
}
